import snowflake.connector

def lambda_handler(event, context):
	print('success')
